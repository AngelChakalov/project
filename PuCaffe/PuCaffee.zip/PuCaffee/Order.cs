﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

public class Order
{
    [Key]
    public int OrderID { get; set; }

    public int CustomerID { get; set; }

    public int CoffeeID { get; set; }

    public int Quantity { get; set; }

    [Required]
    public decimal TotalPrice { get; set; }

    public DateTime OrderDate { get; set; }

    [MaxLength(20)]
    public string OrderStatus { get; set; }

    [ForeignKey("CustomerID")]
    public Customer Customer { get; set; }

    [ForeignKey("CoffeeID")]
    public Coffee Coffee { get; set; }
}