﻿using System.ComponentModel.DataAnnotations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Coffee
{
    [Key]
    public int Id { get; set; }

    [Required]
    [MaxLength(100)]
    public string CoffeeName { get; set; }

    [MaxLength(50)]
    public string CoffeeType { get; set; }

    public decimal? Price { get; set; }

    public DateTime CreationDate { get; set; }

    public int Rating { get; set; }

    // Navigation property for orders
    public List<Order> Orders { get; set; }
}