﻿using Microsoft.EntityFrameworkCore;

public class PuCaffeDbContext : DbContext
{
    public DbSet<Coffee> Coffees { get; set; }
    public DbSet<Customer> Customers { get; set; }
    public DbSet<Order> Orders { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        // Configure your database connection string
        optionsBuilder.UseSqlServer("Server=.;Database=PuKaCaffee;Trusted_Connection=True;");
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Order>()
            .HasOne(o => o.Customer)
            .WithMany(c => c.Orders)
            .HasForeignKey(o => o.CustomerID);

        modelBuilder.Entity<Order>()
            .HasOne(o => o.Coffee)
            .WithMany(c => c.Orders)
            .HasForeignKey(o => o.CoffeeID);
    }
}
